# Differential Gene Expression Analysis of GSE46750

## Project overview

This project analyzes gene-expression differences between inflammatory and normal/reactive synovial tissue regions in osteoarthritis using the public GEO dataset GSE46750.

## Dataset and analysis

- Dataset: GSE46750
- Samples: 24 samples from 12 patients
- Comparison: Inflammatory versus normal/reactive synovial tissue regions
- Statistical method: limma with a paired design accounting for patient
- Significance threshold: adjusted p-value < 0.05
- Significant probes: 152
- Positive log2 fold changes: 120
- Negative log2 fold changes: 32
- Unique annotated gene symbols: 137

## Files

- `GSE46750_limma_annotated_all_probes.csv`: Annotated results for all probes.
- `GSE46750_significant_annotated_probes.csv`: Significant annotated probes.
- `GSE46750_differential_expression_results.csv`: Differential-expression results.
- `GSE46750_GO_BP_enrichment_custom_background.csv`: GO biological-process enrichment results.
- `GSE46750_GO_top_terms_overlapping_genes.csv`: Selected GO terms and overlapping genes.
- `GSE46750_candidate_gene_results.csv`: Candidate-gene results.
- `GSE46750_selected_GO_genes.csv`: Selected genes from GO analysis.
- `GSE46750_volcano_plot.png`: Volcano plot.
- `GSE46750_top20_heatmap.png`: Heatmap of the top 20 significant probes.

## Interpretation

Positive log2 fold changes indicate higher expression in inflammatory regions relative to normal/reactive regions, assuming normal/reactive is the reference group.

## Limitations

This analysis compares two synovial tissue regions from patients with osteoarthritis. It does not compare osteoarthritis patients with healthy controls. Differential expression indicates association, not causation.

## Reproducibility

The CSV files contain analysis outputs. The complete R scripts, software versions, and dataset-processing steps should also be included to enable full reproduction.
